The empty classes directory is reserved for possible fixes.
